class pageObject{
    getVATMenu(){
        return cy.xpath('//div[@class="toc"]/ul/li');
    }
    getCountry(){
        return cy.xpath('//select[@name="Country"]');
    }
    getVATRate(){
        return cy.xpath('//div[@class="col-sm-6 col-12 no-padding"]/label');
    }
    getVATPercent(){
        return cy.xpath('//input[@onclick="vatCalc();drawChart();"]');
    }
    getNetAmt(){
        return cy.get('[id="NetPrice"]');
    }
    getGrossAmt(){
        return cy.get('[id="Price"]');
    }
    getGrossCheck(){
        return cy.xpath('//label[text()="Price incl. VAT"]');
    }
}
export default pageObject