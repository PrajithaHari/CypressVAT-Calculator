import pageObject from './pageObject';
const pageObj = new pageObject();
cy.functions = {
    calculateGrossAmt: (country, amount) => {
        pageObj.getVATMenu().eq(3).click();
        cy.url().should('include', 'https://www.calkoo.com/en/vat-calculator');
        pageObj.getCountry().select(country);
        cy.wait(5000);
        pageObj.getVATPercent().first().invoke('attr', 'value').then(($value) => {
            const percent = parseInt($value);
            pageObj.getVATRate().first().click();
            pageObj.getNetAmt().type(amount, { force: true });
            cy.wait(5000);
            const percentAmount = cy.functions.percentageCalculator(amount, percent);
            const finalAmount = parseFloat(amount) + parseFloat(percentAmount);
            pageObj.getGrossAmt().should('have.value', finalAmount.toFixed(2))
        });

    },
    calculateNetAmt: (country, amount) => {
        pageObj.getVATMenu().eq(3).click();
        cy.url().should('include', 'https://www.calkoo.com/en/vat-calculator');
        pageObj.getCountry().select(country);
        cy.wait(5000);
        pageObj.getVATPercent().first().invoke('attr', 'value').then(($value) => {
            const percent = parseInt($value);
            pageObj.getVATRate().first().click();
            pageObj.getGrossCheck().click();
            pageObj.getGrossAmt().type(amount, { force: true });
            cy.wait(5000);
            const percentAmount = cy.functions.netAmtCalculator(amount, percent);
            pageObj.getNetAmt().should('have.value', percentAmount)
        });

    },
    netAmtCalculator: (amount, percent) => {
        return ((100 * amount) / (100+percent)).toFixed(2)
    },
    percentageCalculator: (amount, percent) => {
        return ((percent * amount) / 100).toFixed(2)
    }
}