import pageObject from '../support/pageObject';
///<reference types="Cypress" />
describe('Test Suite - POC for automated test', () => {
  const pageObj = new pageObject();
  beforeEach(() => {
    cy.visit(`${Cypress.env('url')}`, { log: false });
    cy.on('uncaught:exception', (err) => {
      return false
    })
    cy.wait(3000);
  })
  it('Test case: Calculating price including VAT and VAT rate', () => {
    cy.wait(3000);
    cy.functions.calculateGrossAmt('Austria', 3000.00);
  });
  it('Test case: Calculating price without VAT', () => {
    cy.wait(3000);
    cy.functions.calculateNetAmt('Austria', 3300.00);
  });
})